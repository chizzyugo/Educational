<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SQL FUNCTIONS</title>
    <link rel="stylesheet" href="../css/sql_functions.css">
</head>
<body>
    <div class="pagewrapper">
        <header class="home">
    		<div class="header_container">
    			<div class="logo">
    				<h3>SQL <span class="funcspan">FUNCTIONS</span></h3>
    			</div>
    			<nav class="container_nav">
    				<ul class="nav_list">
    					<li><a href="#" target="_self">login</a></li>
    					<li><a href="#How_it_works" target="_self">How it Works</a></li>
                        <li><a href="#Services" target="_self">Services</a></li>
                        <li><a href="#Contact" target="_self">Contact Us</a></li>
                        <li><a href="#about" target="_self">About Us</a></li>
    					<li class="active"><a href="#Home" target="_self">Home</a></li>
    				</ul>
    			</nav>
    		</div>
        </header>

        <section class="sqlcontiner">
            <div class="sqlBanner">
                <div class="overlayer"></div>
                <div class="functiondiv">
                    <table>
                        <caption> SQL FUNCTIONS</caption>
                        <thead>
                            <tr>
                                <th class="numb">S/N</th>
                                <th class="funs">SQL FUNCTIONS</th>
                                <th class="dest">DESCRIPTION</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>1</td>
                                <td> SQL COUNT Function</td>
                                <td>The SQL COUNT aggregate function is used to count the number of rows in a database table.</td>
                            </tr>

                            <tr>
                                <td>2</td>
                                <td>SQL MAX Function</td>
                                <td>The SQL MAX aggregate function allows us to select the highest (maximum) value for a certain column.</td>
                            </tr>

                            <tr>
                                <td>3</td>
                                <td>SQL MIN Function</td>
                                <td>The SQL MIN aggregate function allows us to select the lowest (minimum) value for a certain column.</td>
                            </tr>

                            <tr>
                                <td>4</td>
                                <td>SQL AVG Function </td>
                                <td>The SQL AVG aggregate function selects the average value for certain table column.</td>
                            </tr>

                            <tr>
                                <td>5</td>
                                <td>SQL SUM Function</td>
                                <td>The SQL SUM aggregate function allows selecting the total for a numeric column.</td>
                            </tr>

                            <tr>
                                <td>6</td>
                                <td>SQL SQRT Functions</td>
                                <td>This is used to generate a square root of a given number.</td>
                            </tr>

                            <tr>
                                <td>7</td>
                                <td>SQL RAND Function</td>
                                <td>This is used to generate a random number using SQL command.</td>
                            </tr>

                            <tr>
                                <td>8</td>
                                <td>SQL CONCAT Function</td>
                                <td>This is used to concatenate any string inside any SQL command.</td>
                            </tr>

                            <tr>
                                <td>9</td>
                                <td>SQL Numeric Functions</td>
                                <td>Complete list of SQL functions required to manipulate numbers in SQL.</td>
                            </tr>

                            <tr>
                                <td>10</td>
                                <td>SQL String Functions </td>
                                <td>Complete list of SQL functions required to manipulate strings in SQL</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </section>

        <footer class="footer_banner">
    		<div class="footer_container">
    			<p class="footer_para">&copy;   2020  All Right Reserved.  Designed by <a href="#">Cizzi-Soft Digital</a> </p>
    		</div>
    	</footer>
    </div>
</body>
</html>