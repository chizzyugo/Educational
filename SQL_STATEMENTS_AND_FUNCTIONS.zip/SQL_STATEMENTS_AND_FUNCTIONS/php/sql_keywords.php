<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SQL STATEMENT|KEYWORDS</title>
    <link rel="stylesheet" href="../css/sql_keywords.css">
</head>
<body>
    <div class="pagewrapper">
        <header class="home">
    		<div class="header_container">
    			<div class="logo">
    				<h3>SQL <span class="keyspan">KEYWORDS</span> | <span class="funcspan">STATEMENTS</span></h3>
    			</div>
    			<nav class="container_nav">
    				<ul class="nav_list">
    					<li><a href="#" target="_self">login</a></li>
    					<li><a href="#How_it_works" target="_self">How it Works</a></li>
                        <li><a href="#Services" target="_self">Services</a></li>
                        <li><a href="#Contact" target="_self">Contact Us</a></li>
                        <li><a href="#about" target="_self">About Us</a></li>
    					<li class="active"><a href="#Home" target="_self">Home</a></li>
    				</ul>
    			</nav>
    		</div>
        </header>

        <section class="sqlcontiner">
            <div class="sqlBanner">
                <div class="overlayer"></div>
                <div class="keys_statement">
                    <table colspan=3>
                        <caption>SQL KEYWORDS|STATEMENTS</caption>
                        <thead>
                            <tr>
                                <th class="numbs">S/N</th>
                                <th class="funs">SQL KEYWORDS|STATEMENTS</th>
                                <th class="dest">DESCRIPTION</th>
                            </tr>
                        </thead>

                        <tbody>
                            <tr>
                                <td>1</td>
                                <td>AND</td>
                                <td>AND combines two or more conditions for a single query. <br> All of the conditions used with this operator must be met in order to show the results.</td>
                            </tr>

                            <tr>
                                <td>2</td>
                                <td>ALTER TABLE</td>
                                <td>ALTER TABLE allows you to add or remove columns from a table</td>
                            </tr>

                            <tr>
                                <td>3</td>
                                <td>AS (alias)</td>
                                <td>AS allows you to rename a column or table to a more convenient alias <br> (a correlation name) without changing the original names in the database. </td>
                            </tr>

                            <tr>
                                <td>4</td>
                                <td>BETWEEN</td>
                                <td>BETWEEN operator filters the results and returns only the ones that fit the specified range.<br> You can describe the value of this operator using dates, numbers, or text</td>
                            </tr>

                            <tr>
                                <td>5</td>
                                <td>CREATE DATABASE</td>
                                <td>When you need to create a new database, use the CREATE DATABASE statement. <br> You must have admin rights to do that.</td>
                            </tr>

                            <tr>
                                <td>6</td>
                                <td>CREATE TABLE</td>
                                <td>CREATE TABLE statement creates a new table in a database.</td>
                            </tr>

                            <tr>
                                <td>7</td>
                                <td>DELETE</td>
                                <td>If you need to remove certain rows from the table, use the DELETE FROM statement.</td>
                            </tr>

                            <tr>
                                <td>8</td>
                                <td>GRANT</td>
                                <td>GRANT command is for giving users the access to a database.</td>
                            </tr>

                            <tr>
                                <td>9</td>
                                <td>REVOKE</td>
                                <td>REVOKE command is for taking away users' permisions.</td>
                            </tr>

                            <tr>
                                <td>10</td>
                                <td>COMMIT</td>
                                <td>COMMIT command is for saving every transaction to the database.</td>
                            </tr>

                            <tr>
                                <td>11</td>
                                <td>DROP DATABASE</td>
                                <td>DROP DATABASE is one of the riskiest statements that should be used with extra caution.<br>In SQL, drop means delete – and DROP DATABASE deletes the whole <br> specified database together with all its parameters and data.</td>
                            </tr>

                            <tr>
                                <td>12</td>
                                <td>EXISTS</td>
                                <td>EXISTS operator allows you to check whether a record exists by writing a subquery. <br> If the record is found, the result is displayed based on the statement <br> you use this operator with. You can use it with SELECT, UPDATE, INSERT, and DELETE.</td>
                            </tr>

                            <tr>
                                <td>13</td>
                                <td>INSERT INTO</td>
                                <td>INSERT INTO statement inserts new rows of data into a table.</td>
                            </tr>

                            <tr>
                                <td>14</td>
                                <td>LEFT JOIN</td>
                                <td>LEFT JOIN retrieves records from the left table that match records in the right table. <br> Some databases have a slightly different statement for this – LEFT OUTER JOIN.</td>
                            </tr>

                            <tr>
                                <td>15</td>
                                <td>RIGHT JOIN</td>
                                <td>RIGHT JOIN retrieves records from the right table that match records in the left table. <br> Some databases call this statement differently – RIGHT OUTER JOIN.</td>
                            </tr>

                            <tr>
                                <td>16</td>
                                <td>FULL JOIN</td>
                                <td>FULL JOIN returns all the records that match either in left or right tables.</td>
                            </tr>

                            <tr>
                                <td>17</td>
                                <td>SELECT</td>
                                <td>SELECT is one of the main SQL statements. It selects data from a database <br> and returns the table of results, called the result-set.</td>
                            </tr>

                            <tr>
                                <td>18</td>
                                <td>SELECT DISTINCT</td>
                                <td>SELECT DISTINCT returns only the data that is distinct, and does not include duplicate entries</td>
                            </tr>

                            <tr>
                                <td>19</td>
                                <td>UNION</td>
                                <td>You can combine multiple result-sets using the UNION operator with two or more SELECT statements.</td>
                            </tr>

                            <tr>
                                <td>20</td>
                                <td>UPDATE</td>
                                <td>UPDATE statement is used with the WHERE clause to update data in the table.</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </section>
        
        <footer class="footer_banner">
    		<div class="footer_container">
    			<p class="footer_para">&copy;   2020  All Right Reserved.  Designed by <a href="#">Cizzi-Soft Digital</a> </p>
    		</div>
    	</footer>
    </div>
</body>
</html>