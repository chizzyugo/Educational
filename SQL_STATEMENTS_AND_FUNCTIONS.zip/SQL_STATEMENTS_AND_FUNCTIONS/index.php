<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SQL STATEMENT|KEYWORDS  AND  SQL FUNCTIONS</title>
    <link rel="stylesheet" href="css/goodindex.css">
</head>
<body>
    <div class="pagewrapper">
        <header class="home">
    		<div class="header_container">
    			<div class="logo">
    				<h3>SQL <span class="keyspan">KEYS</span> AND <span class="funcspan">FUNCS</span></h3>
    			</div>
    			<nav class="container_nav">
    				<ul class="nav_list">
    					<li><a href="#" target="_self">login</a></li>
    					<li><a href="#How_it_works" target="_self">How it Works</a></li>
                        <li><a href="#Services" target="_self">Services</a></li>
                        <li><a href="#Contact" target="_self">Contact Us</a></li>
                        <li><a href="#about" target="_self">About Us</a></li>
    					<li class="active"><a href="#Home" target="_self">Home</a></li>
    				</ul>
    			</nav>
    		</div>
        </header>

        <section class="sqlcontiner">
            <div class="overlayer"></div>
            <div class="sqlBanner">
                <div class="keys_statement">
                    <h3><a href="./php/sql_keywords.php" target="_blank"> SQL KEYWORDS|STATEMENTS</a></h3>
                </div>

                <div class="functiondiv">
                    <h3><a href="./php/sql_functions.php" target="_blank"> SQL FUNCTIONS</a></h3>
                </div>
            </div>
        </section>

        <section class="containerBannerSub">
            <div class="subscrib_container">
                <p class="sub_para">Get monthly updates and free resources.</p>
                <form  class="sub_form" action="" method="GET">
                    <input type="email" placeholder="Enter Your Email" required>
                    <button type="submit" name="submit" class="subscrib_btn">Subscribe</button>
                </form>
            </div>
        </section>
        
        <footer class="footer_banner">
    		<div class="footer_container">
    			<p class="footer_para">&copy;   2020  All Right Reserved.  Designed by <a href="#">Cizzi-Soft Digital</a> </p>
    		</div>
    	</footer>
    </div>
</body>
</html>